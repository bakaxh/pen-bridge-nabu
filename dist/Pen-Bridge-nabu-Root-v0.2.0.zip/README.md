# Third-party Pen Button Bridge for Xiaomi Pad 5 (nabu)

将第三方 MPP 触控笔（戴尔 PN7522W、联想 Precision Pen 2 等）的侧键桥接为
`Xiaomi Smart Pen Keyboard` 虚拟输入设备的按键，由
[XiaomiSmartPenPlus（焦点笔 Plus）](../XiaomiSmartPenPlus) LSPosed 模块接管并映射为
单击 / 长按 / 双击动作。

nabu 的小米官方内核源码（`nt36xxx.c`，NT36523 驱动）会把笔帧里的按键位
（`point_data[77] & 0x03`）解析为 `BTN_STYLUS` / `BTN_STYLUS2` 上报，但 ColorOS 17 的
Panz 内核（`4.14.336_bk-Kernel_17.0-Panz`）实测**没有**把这些按键位转发到 evdev。
更麻烦的是，该内核砍掉了全部动态采样机制：无 `CONFIG_KPROBES`、无
`CONFIG_FUNCTION_TRACER`、无 `CONFIG_MODULES`，liuqin 式的 kprobe 方案无法使用。

因此本模块采用 **eBPF tracepoint** 方案（`spi:spi_transfer_stop` +
`bpf_probe_read`，本内核唯一可用的动态观测通道）：

1. BPF 程序过滤 81 字节的触控笔 SPI 报告传输，从驱动固定的堆缓冲
   （`spi_transfer->rx_buf`）读取原始报告 14 字节，写入 BPF 环形 map；
2. 守护进程轮询 map，用与 liuqin 相同的帧状态机（格式字节门控、去重、
   500 ms 释放超时）经 uinput 注入名为 `Xiaomi Smart Pen Keyboard` 的按键设备；
3. LSPosed 模块在 `PhoneWindowManager#interceptKeyBeforeQueueing`
   （ColorOS 回退点）拦截。

**无需标定**：字节位置由协议决定（不是内核编译结果），程序内建；BPF 程序只读
内核内存、只写自己的 map，不碰 tracefs、退出自动卸载。

## 按键映射（实测标定结论）

完整报告字节扫描 + 分键按压测试（v0.2.0）确认：

| 报告字节 | 语义（本固件实测） |
|---|---|
| `point_data[66]` | 格式：01=笔在屏范围，FF=离屏 |
| `point_data[71..72]` | 压力 |
| `point_data[77]` | MiCode 源码的按键字节，**本固件恒为 0** |
| `point_data[76]` bit0 | **侧键按下（任意一个）** |

Panz 固件**不区分**两个物理侧键（分别按压时签名完全相同），因此桥接为单按键
`KEY_PAGEDOWN`，动作可在焦点笔 Plus 中配置。

## 安装

1. 小米平板 5（nabu）刷 ColorOS 17（Panz 内核），Root（KernelSU 或 Magisk）。
2. 安装 XiaomiSmartPenPlus 并在 LSPosed（Vector Framework）中勾选系统框架。
3. 刷入本模块 zip（`dist/Pen-Bridge-nabu-Root-vX.zip`）并重启，开机自动启动。
4. 验证：

   ```sh
   su
   /data/adb/modules/dell_pen_bridge_nabu/bin/control.sh test
   # 按侧键数次后看 mask_frames[2] / transitions 是否 > 0
   ```

## 动作按钮 / 控制

- KernelSU / Magisk 模块动作按钮 = `control.sh toggle`（暂停 / 恢复）。
- `control.sh start|stop|status|test|dump [秒] [文件]`。
- 可选 `/data/adb/dell_pen_bridge_nabu/bridge.conf`：`BTN_BYTE` / `BTN_BIT`
  覆盖默认的按键字节位置（11 / 0）。

## 安全说明

- 只注入 `KEY_PAGEDOWN` 一个按键，不触碰坐标、压力、tilt、触摸事件。
- 不写内核内存、不修改 boot 镜像、不写任何 tracefs 文件。
- 500 ms 无新鲜帧自动释放按键；陈旧帧、畸形帧一律当作全释放处理。

## 构建

```sh
python build_module.py            # 需要 zig（编译 aarch64-linux-musl 静态二进制）
python build_module.py --package-only
```
