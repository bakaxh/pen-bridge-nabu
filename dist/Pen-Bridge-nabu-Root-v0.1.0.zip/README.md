# Third-party Pen Button Bridge for Xiaomi Pad 5 (nabu)

将第三方 MPP 触控笔（联想 Precision Pen 2 / 小新灵动版、戴尔 PN7522W 等）的侧键桥接为
`Xiaomi Smart Pen Keyboard` 虚拟输入设备的两个按键，由
[XiaomiSmartPenPlus（焦点笔 Plus）](../XiaomiSmartPenPlus) LSPosed 模块接管并映射为
单击 / 长按 / 双击动作。

nabu 的小米官方内核源码（`nt36xxx.c`，NT36523 驱动）会把笔帧里的按键位
（`point_data[66]` 格式字节、`point_data[77] & 0x03` 按键掩码）解析为
`BTN_STYLUS` / `BTN_STYLUS2` 上报，但 ColorOS 17 的 Panz 内核
（`4.14.336_bk-Kernel_17.0-Panz`）实测**没有**把这些按键位转发到 evdev
（用 `getevent` 监听 `NVTCapacitivePen` 按侧键无任何 EV_KEY），因此本模块采用与
[dell-pen-bridge-liuqin](../dell-pen-bridge-liuqin) 相同的方案：

1. kprobe 挂载 `nvt_ts_work_func`，从内核栈上的原始报告缓冲读取字节 66/71/72/75/76/77；
2. 守护进程读取私有 trace_pipe，把按键掩码（bit1=上侧键→KEY_PAGEDOWN，bit0=下侧键→KEY_PAGEUP）
   经 uinput 注入一个名为 `Xiaomi Smart Pen Keyboard` 的按键设备；
3. LSPosed 模块在 `PhoneWindowManager#interceptKeyBeforeQueueing`（ColorOS 回退点）拦截。

与 liuqin 的差别：nabu 驱动是**内建**（probe 符号无模块哈希、无 `.ko` 哈希校验），且
代码偏移 / 栈偏移依赖 Panz 内核的具体编译结果，因此本模块内置
`control.sh calibrate` 自动标定，一次性找到偏移并写入
`/data/adb/dell_pen_bridge_nabu/probe.conf`。

## 安装

1. 小米平板 5（nabu）刷 ColorOS 17（Panz 内核），Root（KernelSU 或 Magisk）。
2. 安装 XiaomiSmartPenPlus 并在 LSPosed 中勾选系统框架。
3. 刷入本模块 zip（`dist/Pen-Bridge-nabu-Root-vX.zip`）并重启。
4. **首次使用必须标定**（需要触控笔在旁）：

   ```sh
   su
   /data/adb/modules/dell_pen_bridge_nabu/bin/control.sh calibrate
   ```

   按提示让笔持续接触屏幕书写。标定完成后模块自动启动；按侧键并用
   `control.sh status` 观察 `mask_frames[1..3]` 是否计数。

## 动作按钮 / 控制

- KernelSU / Magisk 模块动作按钮 = `control.sh toggle`（暂停 / 恢复）。
- `control.sh stop|start|status|calibrate` 同 liuqin 版。

## 安全说明

- 只注入 `KEY_PAGEUP` / `KEY_PAGEDOWN` 两个按键，不触碰坐标、压力、tilt、触摸事件。
- 不写内核内存、不修改 boot 镜像；kprobe 事件使用独立 trace 实例，退出时自动清理。
- 500 ms 无新鲜帧自动释放按键；陈旧帧、畸形帧一律当作全释放处理。

## 构建

```sh
python build_module.py            # 需要 zig（编译 aarch64-linux-musl 静态二进制）
python build_module.py --package-only
```

## 已知限制

- 标定依赖 `nvt_ts_work_func` 栈帧布局，换内核需重新标定（check.sh 会拦截）。
- 触控固件是否透传 MPP 笔的侧键位未在 nabu 上最终验证：若标定成功但按键
  `mask_frames` 始终为 0，说明该固件不上报按键位，此方案对这支笔不可行
  （需要换用「触控固件级」方案，见 README 的 troubleshooting）。
